import { Button } from "@/components/ui/button";
import { ArrowRight, MessageCircle } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-16 gradient-hero relative overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 border border-white/20 rounded-full"></div>
      <div className="absolute bottom-10 right-10 w-32 h-32 border border-white/10 rounded-full"></div>
      <div className="absolute top-1/2 left-1/4 w-2 h-2 bg-white/30 rounded-full animate-pulse"></div>
      <div className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/20 rounded-full animate-pulse delay-1000"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6 leading-tight">
            Siap Memiliki Website Profesional 
            <span className="block text-accent">Anda Sendiri?</span>
          </h2>
          
          <p className="text-xl text-white/90 mb-8 leading-relaxed">
            Jangan biarkan bisnis Anda tertinggal di era digital. 
            Wujudkan website impian Anda sekarang juga dengan tim professional kami!
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-white/90 transition-smooth text-lg px-8 py-4 h-auto group"
            >
              <span className="mr-2">Mulai Proyek Anda Sekarang</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-smooth" />
            </Button>
            
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary transition-smooth text-lg px-8 py-4 h-auto"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Konsultasi Gratis
            </Button>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-white">
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">💰</div>
              <div className="text-lg font-semibold">Harga Terjangkau</div>
              <div className="text-white/80">Mulai dari 2.5 juta</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">⚡</div>
              <div className="text-lg font-semibold">Proses Cepat</div>
              <div className="text-white/80">5-7 hari kerja</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">🛡️</div>
              <div className="text-lg font-semibold">Garansi 30 Hari</div>
              <div className="text-white/80">Support penuh</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;