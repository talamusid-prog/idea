import { useState } from "react";
import { ExternalLink, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

const Portfolio = () => {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const projects = [
    {
      id: 1,
      title: "Toko Online Fashion",
      category: "E-commerce",
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop",
      description: "Website toko online modern dengan sistem pembayaran terintegrasi"
    },
    {
      id: 2,
      title: "Klinik Kesehatan",
      category: "Healthcare",
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=600&h=400&fit=crop",
      description: "Website klinik dengan sistem booking online dan manajemen pasien"
    },
    {
      id: 3,
      title: "Restaurant Makanan",
      category: "Food & Beverage",
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop",
      description: "Website restaurant dengan menu online dan sistem reservasi"
    },
    {
      id: 4,
      title: "Perusahaan Konstruksi",
      category: "Construction",
      image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=600&h=400&fit=crop",
      description: "Website corporate dengan portfolio proyek dan testimoni klien"
    },
    {
      id: 5,
      title: "Sekolah Privat",
      category: "Education",
      image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=400&fit=crop",
      description: "Website sekolah dengan sistem informasi dan portal siswa"
    },
    {
      id: 6,
      title: "Wedding Organizer",
      category: "Event Planning",
      image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=400&fit=crop",
      description: "Website wedding organizer dengan galeri dan paket layanan"
    }
  ];

  return (
    <section id="portfolio" className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Contoh Website Buatan Kami
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Lihat beberapa hasil karya terbaik kami yang telah membantu 
            berbagai bisnis berkembang di dunia digital
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div 
              key={project.id}
              className="group relative overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-smooth bg-card"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-smooth"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-smooth">
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex gap-2">
                      <Button size="sm" className="gradient-primary text-white">
                        <Eye className="w-4 h-4 mr-1" />
                        Lihat
                      </Button>
                      <Button size="sm" variant="outline" className="border-white text-white hover:bg-white hover:text-black">
                        <ExternalLink className="w-4 h-4 mr-1" />
                        Kunjungi
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="mb-2">
                  <span className="inline-block px-3 py-1 text-xs font-semibold text-accent bg-accent/10 rounded-full">
                    {project.category}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-2">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg" 
            variant="outline" 
            className="border-primary text-primary hover:bg-primary hover:text-white transition-smooth"
          >
            Lihat Portfolio Lengkap
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;