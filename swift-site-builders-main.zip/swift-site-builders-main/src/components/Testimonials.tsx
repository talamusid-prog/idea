import { Star, Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const Testimonials = () => {
  const testimonials = [
    {
      name: "Budi Santoso",
      position: "Pemilik Toko Online",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Website toko online yang dibuat sangat professional dan user-friendly. Penjualan saya meningkat 300% setelah menggunakan website dari WebCraft Pro!"
    },
    {
      name: "Dr. Sarah Wijaya",
      position: "Dokter Klinik Kesehatan",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Pelayanan excellent! Website klinik kami jadi lebih modern dan pasien bisa booking online dengan mudah. Tim WebCraft sangat responsif dan professional."
    },
    {
      name: "Ahmad Rahman",
      position: "CEO Perusahaan Konstruksi",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Website corporate yang dibuat sangat representatif untuk perusahaan kami. Design elegan dan fitur portfolio yang memudahkan client melihat project kami."
    },
    {
      name: "Siti Nurhaliza",
      position: "Wedding Organizer",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Amazing! Website wedding organizer kami jadi terlihat sangat elegant dan romantic. Banyak client yang tertarik setelah melihat website kami."
    },
    {
      name: "Rudi Hartono",
      position: "Pemilik Restaurant",
      image: "https://images.unsplash.com/photo-1480429370139-e0132c086e2a?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Website restaurant dengan menu online yang sangat membantu customer. Reservasi online juga memudahkan operasional restaurant kami. Highly recommended!"
    },
    {
      name: "Maya Sari",
      position: "Kepala Sekolah",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Website sekolah yang informatif dan mudah digunakan oleh siswa dan orang tua. Portal siswa sangat membantu untuk komunikasi sekolah dengan keluarga."
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Apa Kata Klien Kami?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Kepuasan klien adalah prioritas utama kami. 
            Lihat testimoni dari berbagai klien yang telah mempercayakan website mereka kepada kami
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index} 
              className="relative hover:shadow-xl transition-smooth border-0 shadow-lg"
            >
              <CardContent className="p-6">
                {/* Quote Icon */}
                <div className="absolute -top-4 left-6">
                  <div className="w-8 h-8 gradient-primary rounded-full flex items-center justify-center">
                    <Quote className="w-4 h-4 text-white" />
                  </div>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-1 mb-4 mt-2">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                  ))}
                </div>

                {/* Testimonial Text */}
                <p className="text-muted-foreground italic leading-relaxed mb-6">
                  "{testimonial.text}"
                </p>

                {/* Customer Info */}
                <div className="flex items-center gap-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-secondary">
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {testimonial.position}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-4 px-8 py-4 bg-success/10 rounded-full">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-accent text-accent" />
              ))}
            </div>
            <span className="text-success font-semibold">
              4.9/5 dari 500+ review klien
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;