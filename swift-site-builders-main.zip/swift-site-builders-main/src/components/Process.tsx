import { MessageCircle, Palette, Code, Rocket } from "lucide-react";

const Process = () => {
  const steps = [
    {
      number: "01",
      icon: MessageCircle,
      title: "Konsultasi",
      description: "Pilih paket dan diskusikan kebutuhan website Anda dengan tim ahli kami",
      color: "text-primary"
    },
    {
      number: "02",
      icon: Palette,
      title: "Desain",
      description: "Kami rancang tampilan website yang menarik sesuai dengan brand dan keinginan Anda",
      color: "text-accent"
    },
    {
      number: "03",
      icon: Code,
      title: "Pengembangan",
      description: "Proses pembuatan website dilakukan oleh tim developer berpengalaman",
      color: "text-success"
    },
    {
      number: "04",
      icon: Rocket,
      title: "Peluncuran",
      description: "Website Anda siap online dan dapat diakses oleh pengunjung di seluruh dunia",
      color: "text-warning"
    }
  ];

  return (
    <section id="process" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Bagaimana Cara Kerjanya?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Proses pembuatan website yang mudah dan transparan. 
            Dari konsultasi hingga website online hanya dalam beberapa langkah
          </p>
        </div>

        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent transform -translate-y-1/2"></div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div 
                key={index}
                className="relative text-center group"
              >
                {/* Step Number */}
                <div className="relative mb-6">
                  <div className="w-24 h-24 mx-auto bg-background border-4 border-muted rounded-full flex items-center justify-center group-hover:border-primary transition-smooth relative z-10">
                    <step.icon className={`w-10 h-10 ${step.color} group-hover:scale-110 transition-smooth`} />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 gradient-primary rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {step.number}
                  </div>
                </div>

                {/* Content */}
                <div className="space-y-3">
                  <h3 className="text-xl font-semibold text-secondary">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Arrow for mobile */}
                {index < steps.length - 1 && (
                  <div className="lg:hidden flex justify-center mt-8 mb-4">
                    <div className="w-px h-8 bg-gradient-to-b from-primary to-transparent"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-success/10 text-success rounded-full font-semibold">
            ⏱️ Rata-rata waktu pengerjaan: 5-7 hari kerja
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;